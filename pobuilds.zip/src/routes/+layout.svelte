<script>
    import "open-props/style.css";
    import "open-props/normalize.css";
    import "$lib/main.scss"
</script>

<slot />


